# **THE LEADERS NEWSPAPER OFFICIAL WEBSITE** 
_______________

> **Designed, Developed, and Launched by Fatherly P. Titus** 
> **for The Leaders Newspaper Ltd.** 

### This is the official webpage of The Leaders Newspaper, a privately owned and registered local news network.

### The project was assigned to the developer on July 2024.  
### Total duration of production time (including testing, optimization and subsequent launch): 5+ months.

## Code Base: 
### The technologies used to developed this project from start to finish include: 
- **HTML5 / CSS** 
- **W3CSS Framework** 
- **JQuery (latest stable release )** 
- **Node.JS** 
- **Vanilla JS** 
- **MySQL** 
- **PHP** 


## Technical Report & Analysis: 
- A serious back-door vulnerability at **Sector alpha-9**, to be fixed by next update.

