var registered_accounts = [];

var account_obj = {
    "id" : "",
    "date" : "",
    "username" : "",
    "email" : "",
    "password" : "",
}


function INIT_signUp(){
    
}



function loadDB(){
  console.log("retrieving entries")
  var json_arr=[],obj;
  $.get("scripts/DummyFiles/dummy_accounts.txt",function(data,status){
      //alert("Status: "+status)
    if(status == "success"){
      //alert("Success");
      json_arr = data.split("*");
        json_arr.forEach((val)=>{
          obj = JSON.parse(val); 
         // console.log(obj)
          registered_accounts.push(obj);
        });
        
      console.log("Entries: "+json_arr.length)
    }else{
        //("Failure!");
    }
  });   
}

account_obj = {
  "name" : "",
  "address" : "",
  "email" : "",
  "phone" : "",
  "password" : "",
  "pin" : "",
}

var user_activity = {
  "liked" : [],
}

function validateSignupData(obj){
    /*
    validate that =>
    • all entries are in appropriate format
    • there exist no other email and phone number of same value
    */
    
    var status = true; 
    /* true -> validation confirm
       false -> validation failed
    */
     var validation_status_arr = [];
     var u_name = obj.data[0], 
      u_address = obj.data[3],
      u_password = obj.data[4],
      u_password_confirm = obj.data[5];
    
     var r_mail, u_mail = obj.data[1];
     var r_phone, u_phone = obj.data[2];
    
      validation_status_arr[0] = isNameValid(u_name);
      validation_status_arr[1] = isEmailValid(u_mail);
      validation_status_arr[2] = isPhoneValid(u_phone);
      validation_status_arr[3] = isAddressValid(u_address);
      validation_status_arr[4] = isPasswordValid(u_password,u_confirm_password);
    
    for(let i = 0; i < validation_status_arr.length; i++){
        stat = validation_status_arr[i];
        
    }
    
    for(let i = 0; i < registered_accounts.length; i++){
        r_mail = registered_accounts[i].data[1];
        r_phone = registered_accounts[i].data[2];
        
        if((u_mail.search(r_mail) > -1) || (u_phone.search(r_phone) > -1)){
            status = false;
            break;
        }
    } if(status == true){
        signup(obj);
    }
      stat_msg = (status == false)? "Validation Failed !" : "Validation Success !";
      alert(stat_msg);
}

function signup(obj){
    var pin_id = "";
    
    console.log(`Account Registered !\nForm ID: ${obj["form_id"]}\nForm Data: ${obj["data"]}`);
    registered_accounts.push(obj);
    return pin_id;
}

function signin(){
    
}


function isNameValid(name){
    var stat = false;
    
    return stat;
}

/****
<div id="signup-form-container" class="w3-container w3-border w3-card-4 w3-small">
      <h1 class="w3-xlarge">Membership Form</h1>  
      <form id="signup-form" style="font-weight:bold;" class="w3-text-amber w3-panel">
      <label for="sgn-name"> Enter Full Name:
       <input id="sgn-name" type="text" class="w3-input w3-border" placeholder="name">
      </label><br>
     <label for="sgn-email"> Enter Email Address:
       <input id="sgn-email" type="text" class="w3-input w3-border" placeholder="email">
      </label><br>
      <label for="sgn-phone"> Enter Phone Number:
       <input id="sgn-phone" type="text" class="w3-input w3-border" placeholder="phone">
      </label><br>
        <button class="w3-btn w3-border w3-border-amber w3-text-amber">Sign Up</button>
      </form>
    </div>
****/

function getDate(){
    mnths = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sept","Oct","Nov","Dec"];
    var d = new Date();
    var df = `${d.getDay()}/${mnths[d.getMonth()]}/${d.getFullYear()}`;//  [dd/mm/yyyy]
    return df;
}

function generateID(){
    var id = "id_";
    for(let i = 0; i < 10;i++){
        id += math.floor(math.random()*9);
    } return id;
}

function createTag(type){
    obj = document.createElement(type);
    console.log("Created Tage Object:=> "+type);
    return obj
}

function getElemById(id){
    return document.getElementById(id);
}
