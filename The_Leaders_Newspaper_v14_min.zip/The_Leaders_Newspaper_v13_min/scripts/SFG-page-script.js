var page_visit_mark = 0;

var cookies = document.cookies;
 //alert(cookies);

const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
const  current_d = new Date();
let current_month = months[current_d.getMonth()],
    current_year = current_d.getFullYear(),
    current_day = current_d.getDay(),
    current_hour = current_d.getHours(),
    current_mins = current_d.getMinutes();

var current_date = `${current_day}/${current_month}/${current_year} ${current_hour}:${current_mins}`;

let pageContent_arr = [];
/*subhead title*/

appendPageContentLinks("Introduction","Overview","Planting Methods","Harvesting","Storing")
loadPageContentLinks();


let articles_arr = [];
  /*
 articles_arr[i] => {"title_string":"string", 
     "link_str":"string"}
*/

//// DYNAMIC LOADING LINKS
addArticleEntry("Google","www.google.com");
addArticleEntry("Facebook","www.facebook.com");
addArticleEntry("Twitter","www.twitter.com");

loadArticlesList("related-articles-list");
///******

//setSubSectionText("SFG-Articles/how-to-grow-potatoes.txt");

function openSideBar(){
    document.getElementById("main-side-bar").style.width = "50%";
    document.getElementById("main-side-bar").style.display = "block";
}


function closeSideBar(){
    document.getElementById("main-side-bar").style.width = "0";
    document.getElementById("main-side-bar").style.display = "block";
}

function setDate(){
    $("#article-date").html(current_date);
}

function setAuthor(author){
    $("#article-author").html(author);
}

function setHeaderTitle(title){
    $("#main-header").html(title);
}

function setSubheaderTitle(id,title){
    $(`#${id}`).html(title);
}

function setSubheaderImage(id,img_url){
 // $(`#${id}`).html(title);   
   document.getElementById(id).setAttribute("src",img_url);
}

function addListItem(list_id,str){
  document.getElementById(list_id).innerHTML += str;   
}

function appendPageContentLinks(subhead){
    for(let i = 0; i < arguments.length; i++){
        pageContent_arr.push(arguments[i]);
    }
}

function loadPageContentLinks(){
     $("#page-content-table").html("");
    var str = "", sub_str = "", obj = null;
    for(let i = 0; i < pageContent_arr.length; i++){
        obj = pageContent_arr[i];
        str = `<li>${obj}</li>`;
        document.getElementById("page-content-table").innerHTML += str; 
        
        sub_str = `
        <div><h1 style="margin-left:8px;" id="sub-header-${i}" class="w3-xlarge sub-header-text"> <u><b> ${pageContent_arr[i]} (${i+1}) </b></u></h1>
        <p id="sub-section-${i}" class="sub-section-text"></p>
      <img style="width:100%;" id="sub-head-img"+${i} src="assets/potato2.jpg"></div><br>`;
        document.getElementById("sub-sections").innerHTML += sub_str;
    }
}

function addArticleEntry(title,link){
    var obj = {
        "title":title,"link":link,
    }
    articles_arr.push(obj);
}

function loadArticlesList(id){
    $(`#${id}`).html("");
    var str = "", obj = null;
    for(let i = 0; i < articles_arr.length; i++){
        obj = articles_arr[i];
        str = `<li><a href="${obj.link}">${obj.title}</a></li>`;
        document.getElementById(id).innerHTML += str; 
    }
}


function setSubSectionText(file){
    var file_data = "";
    
    ///alert("extracting subsection")
    $.get("scripts/"+file,function(data,status){
       //alert(status);
       if(status == "success"){
           file_data = data.split("######");
          // alert("EXTRACTION SUCCESSFUL!")
           
           for(let i = 0; i < file_data.length; i++){
               sub_sect = "sub-section-"+i;
         document.getElementById(sub_sect).innerHTML = file_data[i];     
           }        
       }else{
           alert("fail");
       } 
    });
    
}


function setCookie(cname, cvalue, exdays) {
  const d = new Date();
  d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
  let expires = "expires="+d.toUTCString();
  document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

function getCookie(cname) {
  let name = cname + "=";
  let decodedCookie = decodeURIComponent(document.cookie);
  let ca = decodedCookie.split(';');
  for(let i = 0; i <ca.length; i++) {
    let c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}

function checkCookie() {
  let username = getCookie("username");
  if (username != "") {
   alert("Welcome again " + username);
  } else {
    username = prompt("Please enter your name:", "");
    if (username != "" && username != null) {
      setCookie("username", username, 365);
    }
  }
}


