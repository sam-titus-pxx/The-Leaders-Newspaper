
var article = "";
var user_obj = {
    "user" : "",
    "user_image" : "",
    "user_id" : ""
};

var article_obj = {
    "id" : "",
    "author" : "Mr. Fatherly P. Titus",
    "date" : "",
    "title" : "",
    "cover" : "",
    "keywords" : [],
    "content" : "",
    "tags" : [],
    
    "subcontent" : {
        "subcontents" : [],
    },
}

var sobj = {
    "title" : "",
    "image" : "",
    "link" : "",
    "content" : "",
}

article_page_obj = {
"url" : "",
"page_title" : "",
"page_id" : "",
"keywords" : "",
"tags" : "",
"author_name" : "",
"content" : "",
}


var article_author = "Mr. Fatherly Powered Titus";
var sub_div = null, append_obj = null;
var str = "";


function routePage(){
    DTO = getData("DTO");
    
    ref = DTO.ref_id
    file = DTO.file_path
    title = DTO.title
    cover = DTO.cover
    author = DTO.author
    date = DTO.date
    subcontents = DTO.subcontents

    
    var sub_str = ``
    sublen = subcontents.length;
     //console.log(`Sub Length: ${sublen}`);
    
    for(let i = 0; i < sublen; i++){
        
       sub_str += `
        <div>
        <h1 style="padding-left:3px;" class="w3-large sub-header header">${pg_obj.titles[i].innerHTML}</h1>
        <img style="width:100%;height:150px;" class="sub-cover sub-image" src="${pg_obj.images[i].src}">
        <p class="c-text1 " style="padding-left:3px;">${subcontents[i].innerText}</p>
        </div>
        `
    }  
}


/*
 We want to load the Article Page html doc
- populate the different variable entries in it
- and render the file
*/

function loadPageObj(pg_obj){
    
    //set url: url+page_id
    
  var sub_str = ``
    sublen = pg_obj.contents.length;
     //console.log(`Sub Length: ${sublen}`);
    
    for(let i = 0; i < sublen; i++){
        
       sub_str += `
        <div>
        <h1 style="padding-left:3px;" class="w3-large sub-header header">${pg_obj.titles[i].innerHTML}</h1>
        <img style="width:100%;height:150px;" class="sub-cover sub-image" src="${pg_obj.images[i].src}">
        <p class="c-text1 " style="padding-left:3px;">${pg_obj.contents[i].innerText}</p>
        </div>
        `
    }
    
     //console.log(cntnt);
        //meta
        author = pg_obj.meta[0];
        date = pg_obj.meta[1];
        tags = pg_obj.tags;
        keywords = pg_obj.keywords;
       /* views = pg_obj.meta[2];
        likes = pg_obj.meta[3];*/
        
    
  var str = `
  <div style='padding:0;margin:0; padding-bottom:10px;' class='mg-bg w3-container w3-section w3-card-4'>
    <h1 style='margin-right:10px;' class="w3-small header w3-right"><b class="w3-border-red w3-topbar w3-bottombar w3-small header">TLN</b></h1>
    <div style="margin:0;padding:0;padding-left:15px;">
    <h1 class='w3-xxlarge sub-header header underline bolder'>${pg_obj.head_title}</h1>
      <p class="w3-small bold">
        <span class="thin italic">Written By</span> <span class="w3-text-blue fas fa-user-circle">${author}</span><br>
        ${date}
        </p>
        <p class="w3-small bold w3-text-red"><i class="fas fa-tags"></i> ${tags}</p>
     </div>   
  <div style='margin:0;padding:0;padding-bottom:10px;' class='w3-container w3-bottombar'>
   <img style='width:100%;height:150px;' src='${pg_obj.cover_image}' >
  </div>
    
    ${sub_str} 
  </div>`
    
    //load_SEGMENT("content",str)
    getElem('article-page-main').innerHTML = str;
}


function page_format(title,image,content,date,file_path){
  var str = `<div style='padding:0;margin:0; padding-bottom:10px;' class='mg-bg w3-container w3-section w3-card-4'>
    <h1 style='margin-right:10px;' class="w3-small header w3-right"><b class="w3-border-red w3-topbar w3-bottombar w3-small header">TLN</b></h1>
    <h1 class='w3-xlarge header underline bolder'>${title}</h1>
  <div style='margin:0;padding:0;' class='w3-container'>
   <img style='width:100%;height:100px;' src='${image}' >
  </div>
    <p class="text-box ">${content}...</p>
    <span class="w3-left w3-small bold">${date}</span>
    <button setup-status="false" data-path="${file_path}" type="button" style='padding:5px;' class='btn-read-article w3-btn w3-tiny w3-border w3-white w3-flat-midnight-blue w3-right'>read more</button>
 </div>`
    
    getElem('DFR-prev-display').innerHTML += str;
}

function getDate(){
    mnths = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sept","Oct","Nov","Dec"];
    var d = new Date();
    var df = `${d.getDay()}/${mnths[d.getMonth()]}/${d.getFullYear()}`;//  [dd/mm/yyyy]
    return df;
}

function getElems(cls){
    return document.getElementsByClassName(cls);
}

function generateID(){
    var id = "id_";
    for(let i = 0; i < 10;i++){
        id += Math.floor(Math.random()*9);
    } return id;
}

function createTag(type){
    obj = document.createElement(type);
    console.log("Created Tage Object:=> "+type);
    return obj
}

function getElemById(id){
    return document.getElementById(id);
}

function viewSkeleton(){
    return c_obj.innerHTML;
}