
var user_obj = {
    "id" : "",
    "username" : "",
    "count" : {
        "posts" : "",
        "followers" : "",
        "following" : "",
    },
    "posts" : //[{title,id},{title,id},{title,id}]
    "user_handles" : {
        "facebook" : "",
        "twitter" : "",
        "email" : ""
    },
    "about" : "",
}

var posted_article = {
    "title" : "",
    "id" : "",
}


function INIT_loadUserProfile(user_id){
    
}



