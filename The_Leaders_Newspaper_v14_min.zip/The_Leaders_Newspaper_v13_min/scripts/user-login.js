
    
var accounts_db = new Array(); // [string]
var user_accounts = new Array //[[string]]
var db_loaded = false;

    
 //cstm_modal.INIT_modalDisplay("modal-hoist");

//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////


var email = "", usermail = "", user_password = "";
var log_arr = [];


function INIT_UserLogin(){
  
    loadAccounts();
    
    $("#btn-user-login").click(()=>{
       cred1 = $("#inp-login-username-email").val();
       cred2 = $("#inp-login-password").val();
       
      //determine and validate usermail
       usermail_status = determineUserMail(cred1);
      
     if(usermail_status == 0){
        log_arr.push("Email or Username provided is invalid or does not exist! Please cross-check");
    }else if((usermail_status == 1) || (usermail_status == 2)){
         usermail = cred1;
    //validate password
    password_status = validatePassword(cred2);

    //check whether user already exists
    //run/cross-check creds against exusting database entries
    //if matches == 0, then go ahead and create a new account
    if(password_status){
        user_password = cred2;
        encr_cred1 = encryptText(usermail);
        encr_cred2 = encryptText(user_password);
        
        console.log(`ENCRYPTED USERMAIL: ${encr_cred1} \n\nENCRYPTED PASSWORD: ${encr_cred2}\n`);

        signinUserEncr(encr_cred1,encr_cred2);
        //signinUser(cred1,cred2);
    }else{
      log_arr.push('Invalid Password !'); 
      loadLogAlert();
     }
    }
  });
}
    

function signinUser(usermail,password){
     var user_exists_status = false;
    var log_arr = [];
    accounts_db.forEach((user)=>{
       user = user.username;
       email = user.social_handles.email;
        
       if((usermail == user) || (phonemail == email)){
           log_arr = []; 
           user_exists_status = true;
           log_arr.push("The phone number or email provided is already registered to an account!")
       }
    });
    
    if(!user_exists_status){
        INIT_alertModal("Account with this credentials does not exist!")
    }else if(user_exists_status){
        cstm_modal.INIT_alertModal("Account found and validated !")
        generateUserSessionKey();
        cstm_modal.INIT_buttonActionRouter("index.html")
    }
      return user_exists_status;
}

    
function signinUserEncr(usermail_encr,password_encr){
    
  //decrypt creds
  usermal = decryptCipher(usermail_encr)
  password = decryptCipher(password_encr);
    
  console.log(`DECRYPTED USERMAIL: ${usermail} \n\nDECRYPTED PASSWORD: ${password}\n`);
  
    var user_exists_status = false;
    var log_arr = [];
    accounts_db.forEach((user)=>{
       user = user.username;
        console.log('Username: '+user)
       email = user.social_handles.email;
        
       if((usermail == user) || (phonemail == email)){
           log_arr = []; 
           user_exists_status = true;
           log_arr.push("The phone number or email provided is already registered to an account!")
       }
    });
    
    if(!user_exists_status){
        INIT_alertModal("Account with this credentials does not exist!")
    }else if(user_exists_status){
        cstm_modal.INIT_alertModal("Account found and validated !")
        generateUserSessionKey();
        cstm_modal.INIT_buttonActionRouter("index.html")
    }
      return user_exists_status;
}


function determineUserMail(query_str){
    /*
     The given string could either be username or an email
     We are to determine if the string is in username format
     or if it is in email format.
    * First check username
    * Then check Email
    */
    username_regexp = /^[A-Za-z][A-Za-z0-9_]{7,29}$/;
    email_regexp = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;    
    
    var isUsername = username_regexp.test(query_str);
    var isEmail = email_regexp.test(query_str);
    if(isUsername){
        console.log('Username Value Validated')
        return 1
    }else if(isEmail){
        console.log('Email Value Validated')
        return 2
    }else{
        console.log('Not Username or Email')
        return 0;
    }
}

function determinePhoneMail(query_str){
    /*
     The given string could either be phone number or an email
     We are to determine if the string is in phone no. format
     or if it is in email format.
    * First check phone number
    * Then check Email
    */
    phone_regexp = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/,
    email_regexp = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;    
    
    var isPhone = phone_regexp.test(query_str);
    var isEmail = email_regexp.test(query_str);
    if(isPhone){
        return 1
    }else if(isEmail){
        return 2
    }else{
        return 0;
    }
}

function validatePassword(pwd) {
       var errors = [];
    if (pwd.length < 8) {
        errors.push("Your password must be at least 8 characters"); 
    }
    if (pwd.search(/[a-z]/i) < 0) {
        errors.push("Your password must contain at least one letter.");
    }
    if (pwd.search(/[0-9]/) < 0) {
        errors.push("Your password must contain at least one digit."); 
    }
    if (pwd.search(/[a-z]/) < 0) {
        errors.push("Your password must contain at least one lowercase letter.")
    }
    if (pwd.search(/[A-Z]/) < 0) {
        errors.push("Your password must contain at least one uppercase letter.")
    }
      
      if (errors.length > 0) {
        alert(errors.join("\n"));
        return false;
    }else if(errors.length <= 0){
        password_regex = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/;
        return password_regex.test(pwd);
    }
    return true;
}


function getElem(id){
    return document.getElementById(id);
}


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

function generateUserSessionKey(username,password){
    console.log(`SAVING=> ${username}:${password}`);
    var sess_str = `${username}:${password}`;
   
    localStorage.setItem("user_session_id",sess_str);
}


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

function loadAccounts(){
    $.get("scripts/UserAccountData.txt",function(data,status){
        if(status == "success"){
           //JSON Parse data
            data_obj_arr = JSON.parse(data)
            accounts_db = data_obj_arr;
           
            db_loaded = true;
            //alert("DB Loaded")
        }
    })
}

function loadLogAlert(){
    logs = ""
    if(log_arr.length > 0){
        log_arr.forEach((log)=>{
           logs += log+'<br>';
        });
     INIT_alertModal(logs);
    } console.log("Logs Displayed !");
}
///////////////////////////////////////////////
//////////////////////////////////////////////////
/*
    return {
        "INIT_UserLogin": INIT_UserLogin,
        "signinUser": INIT_UserLogin
    };
    */
    