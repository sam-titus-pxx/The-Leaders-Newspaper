var current_user = null;

//////////////////////////////////////////////////////////////////////////////



//////////////////////////////////////////////////////////////////////////////

var available_lobbies = new Array();
var lobby_objects = new Map() //id,{lobby_name,lobby_id,lobby_users}

lobby_log_obj={
  "logged_in_users" : new Map(), //user_id, log_in time, 
  "logged_out_users" : new Map(), //user_id, log_out_time, login_duration
}

lobby_obj = {
   'comment_log' : new Map(), //id,{id time,sender_id,sender_name,comment}
}


//////////////////////////////////////////////////////////////////////////////
MLU_counter = null;
MLU_arr = new Array(); //["email,pass","email,pass"]


//////////////////////////////////////////////////////////////////////////////

async function getData(){
    const data = await new Promise(function(resolve){
        $.get('scripts/DummyFiles/lobbies-file.txt',function(data,status){
            if (status == "success"){
                data_str = data.split('\n')[0];
              console.log("waiting for timeout")
                setTimeout(function(){
                resolve(data_str);    
                },2500)
                
            }
        })
    }); console.log(`Data Gotten: ${data}`);
}

function addLobbyObject(lob_obj){
    lobby_objects.set(lob_obj.lobby_id,lob_obj);
}

function addLobby(lobby_id){
    available_lobbies.push(lobby_id);
    log(`Available Lobby Added: ${lobby_id}`)
}

function addLobbyAlt(lobby_id,max_participants){
    
}

function addMLU_entry(entry){
    //entry =>["mail,pass","mail,pass"]
    MLU_arr.push(entry);
}

function INIT_MLU(){
    
    if(MLU_arr.length > 0){
        MLU_counter = setInterval(function(){
         login_str = MLU_arr.pop();
         
        mail = login_str.split(",")[0];
        pass = login_str.split(",")[1];
        loginUser(mail,pass);
            
        if(MLU_arr.length == 0){
           clearInterval(MLU_counter);
            MLU_counter = null;
        }
        },1000);8
    }
}
//////////////////////////////////////////////////////////////////////////////


function loadCommentsLog(){
    log_history = lobby_obj.comment_log.size;
    
    if(log_history == 0){
        getElem("comments-area").innerHTML = "No Comments History!"
    }
}

function switchUser(){
    //chamge current user
    current_id = current_user.user_id;
    arr = [];
    lobby_log_obj.logged_in_users.forEach(function(data,key){
       if(key !== current_id){
        arr.push(key); 
       }
    });
   len = arr.length;
   r_pick = Math.floor(Math.random()*len);
   current_user_id = arr[r_pick];
   current_user = lobby_log_obj.logged_in_users.get(current_user_id);
   log(`Current User Changed To: ${current_user.username}`);
 
}

function comment(user,text){
    time = getDateTime();
    username = user.username;
    user_id = user.user_id;
    comment_id = generateID();
    user_dp = `assets/user_profiles/${user.user_dp}`;
    
    comment_obj = {
     "comment_id" : comment_id,
     "time" : time,
     "user_id" : user_id,
     "username" : username,
     "comment" : comment,
    };
    
    lobby_obj.comment_log.set(comment_id,comment_obj)
    
    var str = `<div style='padding:5px 5px;margin:0;width:85%;height:fit-content;border:3px solid blue;' class='w3-panel w3-white w3-section w3-round-large w3-card-4 w3-small w3-border-blue w3-border'>
    <span><img style='height:50px;width:50px;' src='${user_dp}'></span>
    <span class='bold underline'>${username	}</span>
    <p style='margin:0;' class='w3-medium'>${text}</p>
    <span class='w3-tiny w3-right'>${time}</span>
    </div>`;    
    
    //getElem("comments-area").innerHTML = "";
    getElem("comments-area").innerHTML += str;
}

function INIT_multiLogin(user_arr){
    //["email,pass","email,pass","email,pass"]
     
     
}

function loginUser(email,password){
    user = null;
    log("Fetching User Account...");
    $.get("scripts/DummyFiles/user-accounts.txt",function(data,status){
        if(status == "success"){
            log("Acquired User Account File!")
            
            users_data = data.split("\n");
            //log(users_data);
            
            for(let i = 0; i < users_data.length; i++){
                str = users_data[i]; 
                //log(str)
                dta_arr = str.split(",");
                mail = dta_arr[1];
                pass = dta_arr[2];
                
                if((email == mail) && (password == pass)){
                   log(`found User!!\n${email}`)
                   username = dta_arr[0];
                   user_dp = dta_arr[3];
                   id = generateUserID();
                   time = getDateTime();
                    
                   user = {
                     "user_id" : id,
                     "username" : username,
                     "user_dp" : user_dp,
                     "login_time" : time,
                   }
                }
            }
        }
    }); 
    
   setTimeout(function(){
    if(user !== null){
      lobby_log_obj.logged_in_users.set(user.user_id,user);
      log(`User: ${user.username} Logged In To Lobby!`);   
      logged_count = lobby_log_obj.logged_in_users.size;
      getElem("logged-count").innerHTML = logged_count;
      current_user = user;    
    }else{
        log("Could Not Find User Match!")
    }
   },800);
}

function logOutUser(user){
    id = user.user_id;
    username = user.username;
    time = getDateTime();

    user = {
       "user_id" : id,
       "username" : username,
       "logout_time" : time,
    }
    log(`Logging Out ${username} From Lobby....`);
    lobby_log_obj.logged_in_users.remove(id);
    
    lobby_log_obj.logged_out_users.set(id,user);
    logged_count = lobby_log_obj.logged_in_users.size;
    
    log(`User ${username} Logged Out Of Lobby\nTotal Users In Lobby: ${logged_count}\n`)
    getElem("logged-count").innerHTML = logged_count;
}

//////////////////////////////////////////////////////////////////////////////

async function loadLobbies(){
  const lobby_objects = await new Promise(function(resolve){
      var lobby_names = [];
      $.get("scripts/DummyFiles/lobbies-file.txt",function(data,status){
        if(status == "success"){
          f_lines = data.split("\n");
            
           f_lines.forEach((line)=>{
            lobby_name = line.split(',')[0];
            lobby_id = line.split(',')[1];
            lobby_names.push(lobby_name);
               lobby={
                 "lobby_name" : lobby_name,
                 "lobby_id" : lobby_id,
                 "lobby_users" : new Array(),
               };
            addLobbyObject(lobby);
           });
            
          resolve(lobby_names);
        }
    })
  });  //console.log(lobby_objects);
       loadAvailableLobbies();
}

function loadAvailableLobbies(){
    console.log("Loading Lobbies")
    getElem("lobbies-list").innerHTML = "";
    
    var lobby_obj = null, lobby_id = '', lobby_name = '';
    
    lobby_objects.forEach((val,key)=>{
        
        lobby_obj = val;
        
     str = `<div id='' class='w3-bar-item w3-section w3-panel w3-border-black w3-border w3-card-3'>
        <span class='bold underline'>Lobby: ${lobby_obj.lobby_name}</span> <br>
        <span >(${lobby_obj.lobby_id})</span>
        <br>
        <i class='fas fa-users'></i> : &nbsp &nbsp <span class='w3-tag' id='lobby-users'>${val.lobby_users.length}</span>
        <button data-id="${lobby_obj.lobby_id}" class='btn-lobby-entry w3-btn w3-tiny w3-blue w3-right'>Enter</button>
       </div>`;
        
        getElem('lobbies-list').innerHTML += str;
    });
      INIT_lobbyEntryEvent(); 
}

function INIT_lobbyEntryEvent(){
    
    const btns = getElems('btn-lobby-entry');
    for(let i = 0; i < btns.length; i++){
        btn = btns[i];
        
        btn.addEventListener("click",function(){
            lobby_id = btn.getAttribute('data-id');
            
            enterLobby(lobby_id);
        });
    }
}

function enterLobby(id){
    //get all lobby ref data
    //display lobby data
  
    var lobby = lobby_objects.get(id);
   log(`Entering ${lobby.lobby_name} Lobby`)  
}

async function loadLobbyUsers(){
    
    var lobby_status = null; 
    
 const report = await new Promise(function(resolve){
    lobby_status = {
        "logged_users": 0,
        "total_attempts": 0,
        "status": "failed",
    };
     
    var log_count = 0, attempt_count = 0;

    $.get("scripts/DummyFiles/lobby-users-file.txt",function(data,status){
       if(status == "success"){
           f_lines = data.split("\n");
           
           f_lines.forEach((line)=>{
             //console.log(`Data Line: ${line}`);
              user = line.split(",")[0];
              id = line.split(",")[1];
              lobby_id = line.split(",")[2];
               
              //console.log(`Lobby ID: ${lobby_id}`);
               
              attempt_count += 1; log_count += 1;
               
              lobby_status.logged_users = log_count;
              lobby_status.total_attempts = attempt_count;
              
               signinUserLobby(user,id,lobby_id) 
             });
      
           if(lobby_status.logged_users > 0){
               lobby_status.status = "success";
           }
       } 
        resolve(lobby_status);
    });
 }); log(`LoG RePoRT:\nLogged In Users: ${lobby_status.logged_users}\nTotal Attempts: ${lobby_status.total_attempts}\nStatus: ${lobby_status.status}`)
     loadAvailableLobbies();
     //INIT_lobbyEntryEvent();
}

function signinUserLobby(user,id,lobby_id){

   lobby_objects.get(lobby_id).lobby_users.push(user);
    //loadAvailableLobbies();
    console.log(`Signing In ${user} To ${lobby_objects.get(lobby_id).lobby_name}`)
    
}

function updateLobbies(){
    
}

//////////////////////////////////////////////////////////////////////////////

function generateUserID(){
    id = 'uid_';
    for(let i = 0; i < 6; i++){
        id += Math.floor(Math.random()*9);
    } return id;
}

function generateID(){
    id = 'id_';
    for(let i = 0; i < 6; i++){
        id += Math.floor(Math.random()*9);
    } return id;
}


function getDateTime(){
    mnths = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sept","Oct","Nov","Dec"];
    var d = new Date();
    var df = `${d.getHours()}:${d.getMinutes()} [${mnths[d.getMonth()]}/${d.getFullYear()}]`;//  [dd/mm/yyyy]
    return df;
}

function getElems(cls){
    return document.getElementsByClassName(cls);
}

function log(str){
    console.clear();
    console.log(str);
}
//////////////////////////////////////////////////////////////////////////////

