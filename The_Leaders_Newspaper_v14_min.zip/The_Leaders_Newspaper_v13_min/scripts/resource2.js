
import {resource} from 'resource1.js';

var str_text = "There are definitely "+resource;


