
export resource1 = "New Beginnings, Better days ahead!"
