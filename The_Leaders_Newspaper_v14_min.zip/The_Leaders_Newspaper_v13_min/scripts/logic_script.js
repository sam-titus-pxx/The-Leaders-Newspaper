var name, age, gender, reg_no, password;
