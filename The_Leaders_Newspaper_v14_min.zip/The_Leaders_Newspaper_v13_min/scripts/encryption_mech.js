
/*
 Module for handling the encryption of data throughout the site
*/
    
    // *R_ => Receiver_ (receiver's)
var R_PassPhrase; //TILL ON TILL THE days of DARKNESS be GoNE, CoRn and BEanS SHALL BE mounded Upon THE earth. Till THAT DAY COMES !
//= "The Moon is a Harsh Mistress.";
var R_Bits; //= 512; //
    
var R_RSAkey; //= cryptico.generateRSAKey(R_PassPhrase, R_Bits);
var S_RSAkey; // = cryptico.generateRSAKey(PassPhrase, Bits);

var R_PublicKeyString; //daYTrtbtNsK0GwxxV4WVwZhr4HWuiO1f/lOHe7piyqUOXLE3hgbY1Sdj3kOV7+Pbf+NaJCH4O1HnhK+cMh+ozSTGcSuS2Do39T2s142+/8B8BUMkNSbswrxIhLxKE6W7fsFudZEW0osBYNoyKkc9E6Cl5EVjamXOXf5S+sC2UuE=
// = cryptico.publicKeyString(R_RSAkey);       
//print("Sam's public key ID: " + 
var S_PublicKey; //= cryptico.publicKeyID(cryptico.publicKeyString(S_RSAkey));

    
var R_EncryptionResult, R_DecryptionResult; 
//const R_PlainText = "Matt, I need you to help me with my Starcraft strategy.";
    
var cryptico_cipher_call_made; //if the first initial encryptText() call has been made
    
   function INIT_EncryptionMech(passphrase,bit){
      R_PassPhrase = passphrase;
      R_Bits = bit;
    
      R_RSAkey = cryptico.generateRSAKey(R_PassPhrase, R_Bits);
      R_PublicKeyString = cryptico.publicKeyString(R_RSAkey);       
  } 
    
   function INIT_Cryptico(){
       R_PassPhrase = "TILL ON TILL THE days of DARKNESS be GoNE, CoRn and BEanS SHALL BE mounded Upon THE earth. Till THAT DAY COMES !";
       R_Bits = 512;
    
       R_RSAkey = cryptico.generateRSAKey(R_PassPhrase, R_Bits);
       R_PublicKeyString = cryptico.publicKeyString(R_RSAkey);       

       cryptico_cipher_call_made = false
       
       encryptText('Locked and Loaded!')
       console.log("CRYPTICO ENCRYPTION SYSTEM INITIALIZED!")
   } 
    
   function INIT_SGN_Cryptico(){
       R_PassPhrase = "The Moon is a Harsh Mistress.";
       R_Bits = 512;
    
       R_RSAkey = cryptico.generateRSAKey(R_PassPhrase, R_Bits);
       R_PublicKeyString = cryptico.publicKeyString(R_RSAkey);       
       
       S_RSAkey = cryptico.generateRSAKey(PassPhrase, Bits);
       //"Sam's public key ID: "
       S_PublicKey = cryptico.publicKeyID(cryptico.publicKeyString(S_RSAkey));
   }
   
  
function encryptText(text){
  R_EncryptionResult = cryptico.encrypt(text, R_PublicKeyString);   
  //print("The encHirypted message:");
  var encr_cipher = R_EncryptionResult.cipher       
  cipher_call_made = true;    
      return encr_cipher;
}
    
function setEncryptedCipher(cipher){
    R_EncryptionResult.cipher = cipher;
}
    
function decryptCipher(cipher){
    var decr_text = '';
    if(cryptico_cipher_call_made){
    R_DecryptionResult = cryptico.decrypt(R_EncryptionResult.cipher, R_RSAkey);
    //print("The decrypted message:");
    decr_text = R_DecryptionResult.plaintext; 
    }else{
        decr_text = 'NULL';
    }        
   return decr_text;
}    

    
function getSignature(){
   //print("DecryptionResult.signature: " 
   var signature = R_DecryptionResult.signature;
  return signature;   
}
    
/////////////////////////////////////////////////////////////////////
    
    // *S_ => Sender
    
function sgn_encrypt(){
   R_EncryptionResult = cryptico.encrypt(R_PlainText, R_PublicKeyString, S_RSAkey);
   //print("The encrypted message:");
   var encr_cipher = R_EncryptionResult.cipher;        
   return encr_cipher;
 }
    

function sgn_decrypt(){
     R_DecryptionResult = cryptico.decrypt(R_EncryptionResult.cipher, R_RSAkey);
     //print("The decrypted message:");
     var decr_text = R_DecryptionResult.plaintext;        
     return decr_text;
  }
        

function get_decryption_signature(){
   //print("DecryptionResult.signature: " + 
   const decr_signature = R_DecryptionResult.signature;
   return decr_signature;    
}
    
    
function get_signature_key_str(){
   //print("The signature public key string:");
   const decr_public_key = R_DecryptionResult.publicKeyString;        
   return decr_public_key;
}
    
    
function get_signature_key_id(){
//print("The signature public key ID:");
const signature_public_key_id = cryptico.publicKeyID(R_DecryptionResult.publicKeyString);        
return signature_public_key_id;
}


function getCrypticoEncryptionMech(){
    let mech = {
      "Phrase": R_PassPhrase,
      "Bits": R_Bits,
      "Rkey": R_RSAkey,
      "Skey": S_RSAkey,
      "PublicKeyString": R_PublicKeyString,
      "PublicKey": S_PublicKey,
      "EncryptionResult": R_EncryptionResult,  
      "DecryptionResult": R_DecryptionResult,
      "cipher_call_stat": cryptico_cipher_call_made,        
    }
      return mech;
}

function unpackEncrMech(mech){
    R_PassPhrase = mech.Phrase;
    R_Bits = mech.Bits;
    R_RSAkey = mech.Rkey;
    S_RSAkey = mech.Skey;
    R_PublicKeyString = mech.PublicKeyString;
    S_PublicKey = mech.PublicKey;
    R_EncryptionResult = mech.EncryptionKey;
    R_DecryptionResult = mech.DecryptionKey;
    cryptico_cipher_call_made = mech.cipher_call_stat;
    console.log('ENCRYPTION MECH UNPACKED AND INSTANTIATED!')
}
/*
return {
    "INIT_Cryptico": INIT_Cryptico,
    "INIT_SGN_Cryptico": INIT_SGN_Cryptico,
    "encryptText": encryptText,
    "decryptCipher": decryptCipher,
    "getSignature": getSignature,
    "sgn_encrypt": sgn_encrypt,
    "sgn_decrypt": sgn_decrypt,
    "get_decryption_signature": get_decryption_signature
}    
    */

