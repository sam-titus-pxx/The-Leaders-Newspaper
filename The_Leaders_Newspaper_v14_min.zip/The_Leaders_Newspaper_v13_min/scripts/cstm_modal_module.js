define('cstm_modal_module',function(){
    
var hoist_hook = ""; //the id of the div container the modal is to be hoisted
var return_value = null;
var display_timer = 10000, time_elapsed = (display_timer/1000); 
var timer_clock = null;
    
    
//Initialize/setup the modal hoist container to be used.
 
function INIT_modalDisplay(){
    
  if(arguments.length == 1){
    hoist_hook = arguments[0];
    getElem(arguments[0]).innerHTML = modal_body_str;
  }else if(arguments.length == 0){
      document.body.innerHTML += modal_body_str;
  }
   // INIT_plainModal();
}

    
function INIT_buttonActionRouter(link_path){
      INIT_alertModal(`You are being redirected to: <span class="w3-small w3-text-blue"><q>${link_path}</q></span>`)
        
      setTimeout(()=>{
        window.location.href = link_path;      
      },3000);
}   

function INIT_plainModal(){
    $("#cstm-modal #cstm-modal-content").html(modal_plain);
    if(arguments.length > 1){
     //arguments[0] => title
     //arguments[1] => text 
     $("#cstm-modal #cstm-modal-content #modal-title").html(arguments[0]);
     $("#cstm-modal #cstm-modal-content #modal-text").html(arguments[1]);
    }else if(arguments.length == 1){
        $("#cstm-modal #cstm-modal-content #modal-text").html(arguments[0]);
    }
}


function INIT_confirmationModal(){
    $("#cstm-modal #cstm-modal-content").html(modal_dialog);
    if(arguments.length > 1){
     //arguments[0] => title
     //arguments[1] => text 
     $("#cstm-modal #cstm-modal-content #modal-title").text(arguments[0]);
     $("#cstm-modal #cstm-modal-content #modal-text").text(arguments[1]);
    }else if(arguments.length == 1){
        $("#cstm-modal #cstm-modal-content #modal-text").text(arguments[0]);
    }
    
    $("#btn-modal-dialog-no").click(()=>{
       console.log("Dialog Response: NO")
       closeCSTMModal();
    });
     $("#btn-modal-dialog-yes").click(()=>{
       console.log("Dialog Response: YES")
       closeCSTMModal();  
       INIT_buttonActionRouter("login.html");
    });
       openCSTMModal();
}
    
    
function INIT_redirectConfirmationModal(){
    $("#tln-signup-modal #cstm-modal-content").html(modal_dialog);
    if(arguments.length == 3){
     //arguments[0] => title
     //arguments[1] => text 
     //arguments[2] =< redirect link path
     $("#modal-title").text(arguments[0]);
     $("#modal-text").text(arguments[1]);
     redirect_link = arguments[2];
    }else if(arguments.length == 2){
      //arguments[0] => text
      //arguments[1] => link
        $("#modal-text").text(arguments[0]);
        redirect_link = arguments[1];
    }else if(arguments.length == 1){
        redirect_link = arguments[0];
    }
    $("#tln-signup-modal #cstm-modal-content #btn-modal-dialog-no").click(()=>{
       console.log("Dialog Response: NO")
       closeSignupModal();
    });
     $("#tln-signup-modal #cstm-modal-content #btn-modal-dialog-yes").click(()=>{
       console.log("Dialog Response: YES")
       closeSignupModal();  
         
       INIT_buttonActionRouter(redirect_link);
    });  openSignupModal();
}
    

function INIT_alertModal(){
    alert(modal_alert)
  document.querySelector("#cstm-modal #cstm-modal-content").innerHTML = modal_alert;
   if(arguments.length > 1){
    //arguments[0] => title
     //arguments[1] => text 
     $("#cstm-modal #cstm-modal-content #modal-title").html(arguments[0]);
     $("#cstm-modal #cstm-modal-content #modal-text").html(arguments[1]);
    }else if(arguments.length == 1){
        
        alert('Setting Alert Modal Data!: '+arguments[0])
        document.querySelector("#cstm-modal #cstm-modal-content #modal-text").innerHTML = arguments[0];
        alert(document.querySelector("#cstm-modal #cstm-modal-content #modal-text").innerHTML);
            }
   openCSTMModal();
}


function INIT_inputModal(){
  $("#cstm-modal #cstm-modal-content").html(modal_input);
    getElem("btn-modal-input-submit").addEventListener("click",function(){
        return_value = getElem("modal-input-box").value;
        closeCSTMModal();
    })
   if(arguments.length > 1){
    //arguments[0] => title
     //arguments[1] => text 
     $("#cstm-modal #cstm-modal-content #modal-title").html(arguments[0]);
     $("#cstm-modal #cstm-modal-content #modal-text").html(arguments[1]);
    }else if(arguments.length == 1){
        $("#cstm-modal #cstm-modal-content #modal-text").html(arguments[0]);
    }   openCSTMModal();   
    
     $("#tln-signup-modal #cstm-modal-content #btn-modal-input").click(()=>{
      return_value = $("#tln-signup-modal #cstm-modal-content #modal-input-box").val();
    });
}

    
function INIT_timedInputModal(){
  $("#cstm-modal #cstm-modal-content").html(modal_timed_input);
    getElem("btn-modal-input-submit").addEventListener("click",function(){
        return_value = getElem("modal-input-box").value;
        closeCSTMModal();
    })
   if(arguments.length > 1){
    //arguments[0] => title
     //arguments[1] => text 
     $("#cstm-modal #cstm-modal-content #modal-title").html(arguments[0]);
     $("#cstm-modal #cstm-modal-content #modal-text").html(arguments[1]);
       if(arguments.length == 3){
         display_timer = arguments[2];
         time_elapsed = (display_timer/1000);
       }
    }else if(arguments.length == 1){
        $("#cstm-modal #cstm-modal-content #modal-text").html(arguments[0]);
    }   openCSTMModal();   
    
     $("#tln-signup-modal #cstm-modal-content #btn-modal-input").click(()=>{
      return_value = $("#tln-signup-modal #cstm-modal-content #modal-input-box").val();
    });
    
    timer_clock = setInterval(()=>{
      $("#modal-timer-display").text(time_elapsed);
      time_elapsed -= 1;
      if(time_elapsed == 0){
         clearInterval(this);
         clearInterval(timer_clock);
          timer_clock = null;
          console.log('Timer Clock Stopped Running!')
     
      } console.log('Timer Clock Running')
    },950);
    setTimeout(()=>{
      closeCSTMModal();  
    },display_timer);
}


function openCSTMModal(){
  getElem("cstm-modal").style.display = "block"; 
  INIT_btnModalClose();
}

    
function closeCSTMModal(){
  getElem("cstm-modal").style.display = "none"; 
}
    
function INIT_btnModalClose(){
    Array.from(getElems('btn-close-modal')).forEach((btn)=>{
        btn.addEventListener('click',function(){
            closeCSTMModal();
        })
    });
}

function getElem(id){
  return document.getElementById(id);
}

function getElems(cls){
  return document.getElementsByClassName(cls);
}

//set window screen to the top
function slideToTop(){
 window.scrollTo(1,120); 
}


///////////////////////////////////////////////
//////////////////////////////////////////////////

const modal_body_str = `
<div id="cstm-modal" style="display:none;z-index:9;" class="w3-modal w3-grey">
    <div style="height:fit-content;width:10vw;" class="w3-modal-content w3-round-xlarge w3-flat-midnight-blue w3-border">
      <span id="close-cstm-modal" class="btn-close-modal w3-white fa fa-times-circle w3-btn w3-right"></span>  
      <div id="cstm-modal-content" style="height:fit-content;width:100%;padding:0;"class="w3-container w3-round-xlarge w3-card-4 w3-white poppinsB">
    
      </div>
    </div>
  </div>
`;

const modal_plain = `
<div class="w3-panel w3-card-4">
<center>
<h1 class="w3-xlarge w3-underline bolder w3-text-red" id="modal-title">Alert !</h1>

<p class="w3-small bold" id="modal-text">Alert Something Has Happened!</p><br>
<button class="btn-close-modal w3-btn w3-blue w3-small">OK</button>
</center>
</div>
`;

const modal_input = `
<div class="w3-panel w3-card-4">
<center>
<h1 class="w3-xlarge underline bolder w3-text-red cinzelBD" id="modal-title">Alert !</h1>

<p class="w3-small bold poppinsB" id="modal-text">Provide Data Value</p><br>
<div class="w3-section w3-padding">
<input type="text" id="modal-input-box" class="w3-input w3-small w3-hover-sand" placeholder="Enter data...">
<button id="btn-modal-input-submit" class="btn-close-modal w3-section w3-btn w3-blue w3-small bold">OK</button>
</div>
</center>
</div>
`;
    
const modal_timed_input = `
<div class="w3-panel w3-card-4">
<center>
<h1 class="w3-xlarge underline bolder w3-text-red cinzelBD" id="modal-title">Alert !</h1>

<p class="w3-small bold poppinsB" id="modal-text">Provide Data Value</p><br>
<div class="w3-section w3-padding">
 <span id="modal-timer-display" style="" class="pd-tny w3-black w3-tiny w3-right"></span>
 <input type="text" id="modal-input-box" class="w3-input w3-small w3-hover-sand" placeholder="Enter data...">
 <button id="btn-modal-input-submit" class="btn-close-modal w3-section w3-btn w3-blue w3-small bold">OK</button>
</div>
</center>
</div>
`;

const modal_dialog = `<div class="w3-panel w3-card-4">
<center>
<h1 class="w3-xlarge w3-underline bolder w3-text-red" id="modal-title">Alert !</h1>

<p class="w3-small bold" id="modal-text">Confirm Action ?</p>

<div class="w3-panel">
<button class="btn-close-modal w3-btn w3-border w3-text-blue w3-left" id="btn-modal-dialog-no">No</button>
<button class="btn-close-modal w3-btn w3-border w3-blue w3-right" id="btn-modal-dialog-yes">Yes</button>
</div>
</center>
</div>` ;

const modal_alert = `
<div class="w3-panel w3-card-4">
<center>
<h1 class="w3-xlarge w3-underline bolder w3-text-red" id="modal-title">Alert !</h1>

<p class="w3-small bold" id="modal-text">Action Taking Place</p><br>
<button class="btn-close-modal w3-btn w3-blue w3-small">OK</button>
</center>
</div>
`;
    
    
    return {
        "INIT_modalDisplay": INIT_modalDisplay,
        "INIT_plainModal": INIT_plainModal,
        "INIT_confirmationModal": INIT_confirmationModal,
        "INIT_alertModal": INIT_alertModal,
        "INIT_inputModal": INIT_inputModal,
        "INIT_timedInputModal": INIT_timedInputModal,
        "INIT_redirectConfirmationModal": INIT_redirectConfirmationModal,
        "openCSTMModal": openCSTMModal,
        "closeCSTMModal": openCSTMModal,
        "INIT_buttonActionRouter": INIT_buttonActionRouter
    };


});
