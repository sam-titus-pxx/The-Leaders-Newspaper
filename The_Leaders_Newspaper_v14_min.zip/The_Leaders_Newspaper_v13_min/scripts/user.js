/*
The __USER global data object is respinsible for handling certain specific, limited actions & functions   
• User data creation
• User data updating
• User data deletion
• User interactions & activities
*/

