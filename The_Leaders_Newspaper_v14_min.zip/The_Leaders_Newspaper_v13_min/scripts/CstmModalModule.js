
var hoist_hook = "" //the id of the div container the modal is to be hoisted



function INIT_modalDisplay(hoist_id){
    hoist_hook = hoist_id;
    getElem(hoist_hook).innerHTML = modal_body_str;
    INIT_plainModal();
}


function INIT_plainModal(){
    
    $("#cstm-modal #modal-content").html(modal_plain);
    
    if(arguments.length > 1){
     //arguments[0] => title
     //arguments[1] => text 
     $("#cstm-modal #modal-content #modal-title").html(arguments[0]);
     $("#cstm-modal #modal-content #modal-text").html(arguments[1]);
    }else if(arguments.length == 1){
        $("#cstm-modal #modal-content #modal-text").html(arguments[0]);
    }
    
}


function INIT_confirmationModal(){
    
    $("#cstm-modal #modal-content").html(modal_dialog);
    
    if(arguments.length > 1){
     //arguments[0] => title
     //arguments[1] => text 
     $("#cstm-modal #modal-content #modal-title").text(arguments[0]);
     $("#cstm-modal #modal-content #modal-text").text(arguments[1]);
    }else if(arguments.length == 1){
        $("#cstm-modal #modal-content #modal-text").text(arguments[0]);
    }
    
    
    $("#btn-modal-dialog-no").click(()=>{
       console.log("Dialog Response: NO")
       closeCSTMModal();
    });
     $("#btn-modal-dialog-yes").click(()=>{
       console.log("Dialog Response: YES")
       closeCSTMModal();  
         
       INIT_buttonActionRouter("login.html");
    });
    
    openCSTMModal();
}


function INIT_alertModal(){
    
  $("#cstm-modal #modal-content").html(modal_alert);
    
   if(arguments.length > 1){
    //arguments[0] => title
     //arguments[1] => text 
     $("#cstm-modal #modal-content #modal-title").html(arguments[0]);
     $("#cstm-modal #modal-content #modal-text").html(arguments[1]);
    }else if(arguments.length == 1){
        $("#cstm-modal #modal-content #modal-text").html(arguments[0]);
    }
   openCSTMModal();
}


function INIT_inputModal(){
  $("#cstm-modal #modal-content").html(modal_input);
    
   if(arguments.length > 1){
    //arguments[0] => title
     //arguments[1] => text 
     $("#cstm-modal #modal-content #modal-title").html(arguments[0]);
     $("#cstm-modal #modal-content #modal-text").html(arguments[1]);
    }else if(arguments.length == 1){
        $("#cstm-modal #modal-content #modal-text").html(arguments[0]);
    }
   openCSTMModal();   
}



function openCSTMModal(){
  getElem("cstm-modal").style.display = "block"; 
}

function closeCSTMModal(){
  getElem("cstm-modal").style.display = "none"; 
}




function getElem(id){
  return document.getElementById(id);
}

function getElems(cls){
  return document.getElementsByClassName(cls);
}

//set window screen to the top
function slideToTop(){
 window.scrollTo(1,120); 
}



///////////////////////////////////////////////
//////////////////////////////////////////////////

const modal_body_str = `
<div id="cstm-modal" style="display:none;" class="w3-modal w3-grey">
    <div style="height:fit-content;width:10vw;" class="w3-modal-content w3-flat-midnight-blue w3-border-black w3-bottombar w3-rightbar w3-topbar w3-leftbar">
      <span id="close-cstm-modal" class="w3-white fa fa-times-circle w3-btn w3-right"></span>  
      <div id="cstm-modal-content" style="height:fit-content;width:100%;padding:0;"class="w3-container w3-card-4 w3-white">
    
      </div>
    </div>
  </div>
`

const modal_plain = `
<div class="w3-panel w3-card-4">
<center>
<h1 class="w3-xlarge w3-underline bolder w3-text-red" id="modal-title">Alert !</h1>

<p class="w3-small bold" id="modal-text">Alert Something Has Happened!</p><br>
<button onclick="closeCSTMModal()" class="w3-btn w3-blue w3-small">OK</button>
</center>
</div>
`

const modal_input = `
<div class="w3-panel w3-card-4">
<center>
<h1 class="w3-xlarge w3-underline bolder w3-text-red" id="modal-title">Alert !</h1>

<p class="w3-small bold" id="modal-text">Provide Data Value</p><br>
<div>
<input type="text" id="modal-input-box" class="w3-input w3-small w3-hover-sand" placeholder="choose a unique username">
<button onclick="closeCSTMModal()" class="w3-btn w3-blue w3-small">OK</button>
</div>
</center>
</div>
`;

const modal_dialog = `<div class="w3-panel w3-card-4">
<center>
<h1 class="w3-xlarge w3-underline bolder w3-text-red" id="modal-title">Alert !</h1>

<p class="w3-small bold" id="modal-text">Confirm Action ?</p>

<div class="w3-panel">
<button class="w3-btn w3-border w3-text-blue w3-left" id="btn-modal-dialog-no">No</button>
<button class="w3-btn w3-border w3-blue w3-right" id="btn-modal-dialog-yes">Yes</button>
</div>
</center>
</div>` ;

const modal_alert = `
<div class="w3-panel w3-card-4">
<center>
<h1 class="w3-xlarge w3-underline bolder w3-text-red" id="modal-title">Alert !</h1>

<p class="w3-small bold" id="modal-text">Action Taking Place</p><br>
<button onclick="closeCSTMModal()" class="w3-btn w3-blue w3-small">OK</button>
</center>
</div>
`



