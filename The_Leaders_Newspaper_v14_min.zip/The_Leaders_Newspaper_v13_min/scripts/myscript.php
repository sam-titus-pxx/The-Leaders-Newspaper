
$statement = "This is a PHP program statement!";

echo($statement);
