/*
The __ADMIN global object is responsible for:
• Platform activity monitoring
• Traffic observation & control
• Events and content creation 
• Making of announcments
• Making of critical, strategic decisions that affect the platform and the users as a whole
• Access Authorization & control
*/

var __ADMIN = {
    
}

