
var btn_prev_action = function(){
  var index = paginator_obj.current_page;
  if(index > 1){
      paginator_obj.current_page = index-1;
      loadContent(index-1);
      focusButton(index-1);
      unfocusButton(index);
  }
};
    
  var btn_next_action = function(){
   var index = paginator_obj.current_page;
  if(index < paginator_obj.page_count){
      paginator_obj.current_page = index+1;
      loadContent(index+1);
      focusButton(index+1);
      unfocusButton(index);
  }
  };

var paginator_obj = {
    pages : [1,2,3,4,5,6],
    data : ["Hello","There","World","How","Are","You"],
    page_count : 6,
    current_page : 1,
    previous_page : -1,
    next_page : 1,
    
}

function pagifyDataSource(data,lim,opr,div_id){
    /*
    l => by line (\n)
    s => by sentence (.)
    w => by word
    */
    var str = `<div id="pagination-display" class="w3-container"></div>
    <div style="height:fit-content;" id="paginator" class="w3-border w3-panel w3-border-blue">
    <div id="pg-btns" class="w3-bar w3-small"></div>
      <span id="pg-btn-prev" class="w3-button w3-small w3-border w3-blue w3-left"><i class="fas fa-caret-left"></i>prev</span><span id="pg-btn-next" class="w3-blue w3-button w3-border w3-small w3-right">next<i class="fas fa-caret-right"></i></span>
    </div>`;
    $("#"+div_id).html(str);
    
    $("#pg-btn-prev").click(btn_prev_action);
    $("#pg-btn-next").click(btn_next_action);
    
    var str_data_arr = [];
    var count_check = 1;
    //console.log("Initiating Pagination Operation...")
    
    switch(opr){
      case "l" : console.log("Line Pagination") 
        var rows_arr = data.split("\n");
        var row_batch = "";
        for(let i = 1; i < rows_arr.length; i++){
           row_batch += rows_arr[i]+"<br>";
            if(count_check == lim){
             str_data_arr.push(row_batch);
             row_batch = ""; count_check = 0;
           }if((i == rows_arr.length-1) && (count_check != lim)){
             str_data_arr.push(row_batch);
           }
             count_check++;
        }
         paginate(str_data_arr);
        break;
        
       case "s" : console.log("Sentence Pagination")
        sen_arr = data.split(".");
        var sen_batch = "";
        for(let i = 0; i < sen_arr.length; ++i){
            if(count_check == lim){
                str_data_arr.push(sen_batch)
                sen_batch = ""; count_check = 1;
            }if((i == sen_arr.length-1) && (count_check != lim)){
                str_data_arr.push(sen_batch);
            }
            
            sen_batch += sen_arr[i]+".";
            count_check ++;
        }
         paginate(str_data_arr);
        break;
        
        case "w" :
         var wrd_batch = "";
         var wrd_arr = data.split(" ");
        for(let i = 0; wrd_arr.length; i++){
            if(count_check == lim){
                str_data_arr.push(wrd_batch);
                count_check = 1;
            }if((i == wrd_arr.length-1) && (count_check != lim)){
                str_data_arr.push(wrd_batch);
            }
            wrd_batch += wrd_arr[i]+" ";
            count_check++;
        } paginate(str_data_arr);
        break;
    }
    
    alert("Data Source Paginated!!")
}

function paginate(data_arr){
   // paginator_obj.pages = data_arr.length;
    paginator_obj.data = data_arr;
    paginator_obj.page_count = data_arr.length;
    paginator_obj.current_page = 1;
    
    var str = null,first_btn = null;
    for(let i = 1; i <= paginator_obj.page_count;i++){
      str = document.createElement("span");
        str.setAttribute("class","w3-bar-item w3-border w3-btn w3-text-blue");
        str.setAttribute("id",`pg-btn-${i}`);
        str.innerHTML = ""+i;
        
        str.addEventListener("click",function(){
           index = parseInt(this.innerHTML);
           
            paginator_obj.current_page = index;
            if(paginator_obj.previous_page == -1){paginator_obj.previous_page = index;}
            else if(paginator_obj.previous_page !== -1){
                prev_btn = paginator_obj.previous_page;
                var btn = document.getElementById(`pg-btn-${prev_btn}`);
                btn.classList.remove("w3-text-green");
                btn.classList.add("w3-text-blue");
                paginator_obj.previous_page = index;
            }
            
           loadContent(index);
           this.style.disabled = "true";
           this.classList.remove("w3-text-blue");
           this.classList.add("w3-text-green");
        });
       
        if(first_btn == null){first_btn = str;}
      document.querySelector("#paginator #pg-btns").appendChild(str);    
    }
     first_btn.click();
   // $("#paginator").html(str);
}

function loadContent(index){
    content = paginator_obj.data[index-1];
    $("#pagination-display").html(content);
}

function focusButton(index){
    var btn = document.getElementById(`pg-btn-${index}`);
    btn.classList.remove("w3-text-blue");
    btn.classList.add("w3-text-green");
}
function unfocusButton(index){
    var btn = document.getElementById(`pg-btn-${index}`);
    btn.classList.remove("w3-text-green");
    btn.classList.add("w3-text-blue");
}

function displayPagination(div_id){
    var str = `<div id="pagination-display" class="w3-panel w3-card-4"></div>
    <div style="height:fit-content;" id="paginator" class="w3-border w3-panel w3-border-blue">
    <div id="pg-btns" class="w3-bar w3-small"></div>
      <span id="pg-btn-prev" class="w3-button w3-small w3-border w3-blue w3-left"><i class="fas fa-caret-left"></i>prev</span><span id="pg-btn-next" class="w3-blue w3-button w3-border w3-small w3-right">next<i class="fas fa-caret-right"></i></span>
    </div>`;
    $("#"+div_id).html(str);
}

/* HTML LAYOUT FORMAT
   <div class="w3-container w3-border">
    <h1 class="w3-xlarge">Page Display</h1>
    <div id="display" class="w3-panel w3-card-4"></div>
    <div style="height:fit-content;" id="paginator" class="w3-border w3-panel w3-border-blue"><div id="pg-btns" class="w3-bar w3-small"></div>
      <span id="pg-btn-prev" class="w3-button w3-small w3-border w3-blue w3-left"><i class="fas fa-caret-left"></i>prev</span><span id="pg-btn-next" class="w3-blue w3-button w3-border w3-small w3-right">next<i class="fas fa-caret-right"></i></span></div>
  </div>
*/