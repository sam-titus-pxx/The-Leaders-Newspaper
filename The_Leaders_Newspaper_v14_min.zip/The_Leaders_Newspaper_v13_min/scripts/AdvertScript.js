/*
Advertising Object Creater
*/

ad_obj={
    adID: "",
    client: "",
    image: "",
    description: "",
    keywords: "",
    links: ""
}


///////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////

$(document).ready(()=>{
    
///////////////////////////////////////////////////////////

    
});

///////////////////////////////////////////////////////////



///////////////////////////////////////////////////////////



///////////////////////////////////////////////////////////



///////////////////////////////////////////////////////////



///////////////////////////////////////////////////////////
function upperCaseF(word){
    var wrd,f_ltr,word_str,wrds,str="";
    
    if(word.indexOf(" ") > -1){
        //two words
       var words = word.split(" ");
       for(let i = 0; i < words.length; i++){
          wrd = words[i];
          f_ltr = wrd.substr(0,1),
          word_str = wrd.substr(1);
          wrds = f_ltr.toUpperCase()+""+word_str+" ";
          str+=wrds;
       }
    }else if(word.indexOf(" ") == -1){
     f_ltr = word.substr(0,1),
     word_str = word.substr(1);  
     str = f_ltr.toUpperCase()+""+word_str;
    }
    return str;
}

function generateID(){
    var id = 'PCF-';
    
    for(i = 0; i < 8; i++){
        r = math.floor(math.random()*9);
        id += r;
    } return id
}

function showSection(section){
    /*
    *section 0 => Splash
    *section 1 => Access/Login
    *section 2 => Main Form
    *section 3 => Setup Form
    *section 4 => Preview Form
    */
    switch(section){
        case "main-form" :
        console.log('Sec_2: Switching To Access Section')
        getElems('section')[1].style.display = 'none';
        getElems('section')[2].style.display = 'block';
        break;
        case "setup-form" :
        console.log('Sec_3: Switching To Access Section')
        getElems('section')[2].style.display = 'none';
        getElems('section')[3].style.display = 'block';
        
        type = CBT_object.paper_type;
        if(type == 'obj'){
          hideElem('label-sbj-radio-field'); 
        }
        else if(type == 'sbj'){
          hideElem('label-obj-radio-field'); 
        }
        else if(type == 'mixed'){
            shoElem('label-obj-radio-field'); 
            showElem('label-sbj-radio-field'); 
        }
        
        break;
        case "preview" :
        console.log('Sec_4: Switching To Access Section')
        getElems('section')[3].style.display = 'none';
        getElems('section')[4].style.display = 'block';
        break;
        case "access" :
        console.log('Sec_1: Switching To Access Section')
        getElems('section')[0].style.display = 'none';
        getElems('section')[1].style.display = 'block';
        break;
        case "splash" :
         sec_index = 0;
        break;
    }
}

function openModal(){
  getElem("CBT-notification-modal").style.display = "block"; 
}

function closeModal(){
  getElem("CBT-notification-modal").style.display = "none"; 
}

function setUtilModal(){
    /*
    * arguments[0] => head_title
    * arguments[1] => notice_text 
    * arguments[2] => modal_text
    */
    header = arguments[0];
    notice = arguments[1];
    mod_text = arguments[2];
    
    getElem('util-header-title').innerHTML = header;
    getElem('util-notice-text').innerHTML = notice;
    getElem('util-modal-text').innerHTML = mod_text;
    
}

function openUtilModal(){
  getElem("CBT-util-modal").style.display = "block";
}

function closeUtilModal(){
  getElem("CBT-util-modal").style.display = "none"
}

function showINPModal(){
    getElem('CBT-input-modal').style.display = 'block';
    setTimeout(()=>{
    $('#inp-security-admin-passcode').focus();
    },1000);
}

function hideINPModal(){
    getElem('CBT-input-modal').style.display = 'none';
}

function getElem(id){
  return document.getElementById(id);
}

function getElems(cls){
  return document.getElementsByClassName(cls); 
}

function getElemsAll(query){
  return document.querySelectorAll(query); 
}

function showElem(id){
  document.getElementById(id).style.display = 'block'; 
}

function showElems(){
  for(let i = 0; i < arguments.length; i++){
   document.getElementById(arguments[i]).style.display = 'block'; 
  }    
}

function hideElem(id){
  document.getElementById(id).style.display = 'none'; 
}

function hideElems(){
  for(let i = 0; i < arguments.length; i++){
   document.getElementById(arguments[i]).style.display = 'none'; 
  }    
}

function getDate(){
    mnths = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sept","Oct","Nov","Dec"];
    var d = new Date();
    var df = `${d.getDate()}/${mnths[d.getMonth()]}/${d.getFullYear()}`;//  [dd/mm/yyyy]
    return df;
}

function log(str){
  console.log(str);
}

function createTag(type){
    obj = document.createElement(type);
    //console.log("Created Tage Object:=> "+type);
    return obj
}
