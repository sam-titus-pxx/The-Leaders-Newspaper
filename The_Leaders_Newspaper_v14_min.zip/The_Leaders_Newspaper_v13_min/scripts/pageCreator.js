var user =
{
    "Username" : "",
}

var title="", keywords = [], descriptions=[], file="", author="", id="";

var pg_obj = {
    "title" : "Life & Times",
    "author" : user.username,
    "file" : "scripts/DummyFiles/dm6.txt",
    "id" : "#3112",
    "categories" : [],
    "sub_cstegories" : [],
    "description" : "",
    "content" : "",
    "date" : "17/11/2023",
    
}

function formSubmit(){
    
    
    var title = $("#pg-title").val();
     if(title == "" || title == null){
         title = "unknown";
     } pg_obj["title"] = title;
    
    var author = $("#pg-author").val();
     if(author == "" || author == null){
         author = "Anonymous";
     } pg_obj["author"] = author;
    
    var id = $("#pg-id").val();
     if(id == "" || id == null){
         id = "#33321";
     } pg_obj["id"] = id;
    
    var file = $("#pg-file").val();
     pg_obj["file"] = file;
    
    var keywords = $("#pg-keywords").val();
      if(keywords.indexOf(",") > -1){
          pg_obj["keywords"] = keywords.split(",");
      }else{ pg_obj["keywords"].push(keywords);}
    
    var descriptions = $("#pg-descriptions").val();
      if(descriptions.indexOf(",") > -1){
          pg_obj["descriptions"] = descriptions.split(",");
      }else{
          pg_obj["descriptions"].push(descriptions);
      }
    
    var str = `Tile: ${title}\nAuthor: ${author}\nPage ID: ${id}\nSource File: ${file}\nKeywords: ${keywords}\nDescriptions: ${descriptions}\n`;
     alert(str);
    
}


function preview(){
    str = `
    <div class="w3-left w3-border w3-card-4">
    <h1 id="modal-title" class="w3-xlarge"><i class="fas fa-tag"></i>Title: <b><u>${pg_obj["title"]}</u></b></h1>
    <h1 id="modal-author"class="w3-medium"><i class="fas fa-profile"></i>Author: <u>${pg_obj["author"]}</u></h1>
    <h1 id="modal-date"class="w3-tiny"><i class="fas fa-calender"></i>Date: ${pg_obj["date"]}</h1>
    </div>`;
    
    $.get(pg_obj["file"],function(data,status){
       if(status == "success"){
         setTimeout(function(){
             $("#modal-header").html(str);
             pagifyDataSource(data,10,"l","modal-content");
             //$("#modal-content").html(data);
             //$("#btn-preview").leanModal();
         },500);
       } 
    });
}